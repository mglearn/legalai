# BoodleBox Bot — LegalAI Defense Assistant

Everything you need to build a defense-focused AI bot that carries the TCDLAi framework and the ethical guardrails by default. Built for the TCDLA session **AI for the Defense**.

**See it live:** finished versions are already published as examples on **[BoodleBox](https://box.boodle.ai/a/@TCDLALegalAI)** and as a **[LegalAI Custom GPT on ChatGPT](https://chatgpt.com/g/g-6a594b38484c8191bdea73bca6a584e2-legalai)**. Open either to try the bot, or follow the steps below to build your own.

> **Practice safely.** This bot is for drafting, analysis, and issue-spotting. Every output is a draft for attorney review. Use fictional or de-identified facts in consumer tools. Verify all authority in a real database.

---

## What is in this folder

| File | What it is | Where it goes |
|---|---|---|
| `00-custom-instructions.txt` | The bot's persona and rules | Paste into the custom-instructions / system-prompt field |
| `01-tcdlai-prompt-design-guide.txt` | The six-move prompting framework | Upload as knowledge |
| `02-ethics-guardrail-checklist.txt` | Duties, do-and-do-not, checklist | Upload as knowledge |
| `03-verification-workflow.txt` | How to confirm output and cite-check | Upload as knowledge |
| `04-fact-patterns.txt` | Three fictional practice scenarios | Upload as knowledge |
| `05-prompt-library.txt` | Copy-ready starter prompts | Upload as knowledge |
| `06-claude-for-legal-practices.txt` | Element chart, chronology, and matter workspace (adapted from Claude for Legal) | Upload as knowledge |
| `07-what-i-can-do.txt` | The bot's welcome and capabilities message | Paste into the greeting / first message |
| `08-scenario-bank.txt` | 50 fictional Texas fact patterns for practice | Upload as knowledge |

**Prefer one download?** Grab **[LegalAI-BoodleBox-Bot.zip](https://mglearn.github.io/legalai/BoodleBox%20Bot%20LegalAI/LegalAI-BoodleBox-Bot.zip)** (all files, contents are markdown with a `.txt` extension), unzip it, and upload the pieces.

## Build it in BoodleBox

1. Sign in to BoodleBox. If you have a license code from the session, redeem it first.
2. Create a new bot. Name it **LegalAI** and give it a short description, for example: *Drafting and analysis assistant for Texas criminal defense. Every output is a draft for attorney review.* Set its picture using `bot-icon-tcdla.png`, a clean blue-and-silver robot-and-scales avatar with no text (`bot-icon-tcdla.svg` is the editable source).
3. Open the custom-instructions field. Copy the full contents of `00-custom-instructions.txt` and paste it in.
4. Add knowledge files. Upload the numbered knowledge files: `01` through `06` and `08-scenario-bank.txt`.
5. Set the welcome message. Paste `07-what-i-can-do.txt` into the bot's greeting or intro so users see what it does first.
6. Save, then test with a fictional fact pattern from `04-fact-patterns.txt`.

## Build it somewhere else

The same files work in other tools.

- **Claude Project:** create a Project, paste `00` into the project instructions, and add the numbered files to Project knowledge.
- **Custom GPT:** paste `00` into Instructions, and upload the numbered files under Knowledge.
- **Mistral or other agent builders:** paste `00` as the system prompt, and attach the numbered files as context or a knowledge source.

## Test prompts

Try these after you build it. Each should trigger the bot's grounding and verification behavior.

- "Use fact pattern one. Give me five suppression angles, grounded only in the excerpt, and flag anything unsupported."
- "Draft a plain-language client letter explaining a DWI charge. Keep the facts unchanged and add no promises."
- "Here is a case summary you wrote and the source excerpt. Show me every claim the source does not support."

A well-built bot will restate the issue, tie claims to provided facts, mark unverified citations, and remind you that the output is a draft for attorney review.

## If it misbehaves

- **It invents citations.** Re-paste `00` into the instructions field and confirm the knowledge files uploaded. Add: "Cite only sources I provide in this chat."
- **It gives final-sounding answers.** Remind it: "Every output is a draft for attorney review. Flag what I must verify."
- **It asks for client details.** Good. Give it fictional stand-ins, not real identifying facts.

---

*Facilitator: Miguel Guhlin · Session resources at mglearn.github.io/legalai*
